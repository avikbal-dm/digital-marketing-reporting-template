---
name: Feature or tab request
about: Suggest a new tab, metric, or data source
title: "[idea] "
labels: enhancement
---

**What would you add?**
A tab, metric, or data source and why it helps a monthly review.

**Source**
Which tool would the data come from (GA4, Search Console, Google Ads, LinkedIn, other)?

**Anything else**
Sketches, column ideas, or examples.
