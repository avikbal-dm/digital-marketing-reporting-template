# Publishing this repo on GitHub

Everything you need to push this repo and make it rank and convert. Follow it top to bottom once.

## 1. Create the repo

- **Repository name:** `digital-marketing-reporting-template`
- **Visibility:** Public
- Do not initialize with a README (you already have one).

A keyword-rich repo name is the single biggest GitHub SEO lever. Keep this slug.

## 2. About box (right sidebar)

Set the **Description** to this exact line. It is what Google shows under the result and what GitHub search matches on:

> Free digital marketing reporting template for Excel, filled by Claude. Pull GA4, Search Console, Google Ads, LinkedIn, and PageSpeed in minutes. Plug-and-play monthly marketing report and KPI dashboard.

Set the **Website** field to your LinkedIn or personal site.

## 3. Topics (tags)

Add these topics in the About box. Topics drive GitHub topic-page discovery, so use all 20:

```
marketing-reporting, marketing-dashboard, digital-marketing, marketing-report-template,
excel-template, ga4, google-analytics, seo-report, ppc-reporting, kpi-dashboard,
google-search-console, linkedin-ads, google-ads, core-web-vitals, claude,
windsor-ai, marketing-analytics, agency-reporting, reporting-template, marketing-kpi
```

## 4. Social preview image

Settings > General > Social preview. Upload a 1280x640 PNG. This is the image that shows when the repo is shared on LinkedIn and X, so it drives click-through. A simple branded title card with the repo name and "17 tabs. Claude-ready." works well.

## 5. Push the files

From the folder that contains this README, template/, and docs/:

```bash
git init
git add .
git commit -m "Digital marketing reporting template, Claude data-pull ready"
git branch -M main
git remote add origin https://github.com/<your-username>/digital-marketing-reporting-template.git
git push -u origin main
```

## 6. First-release checklist

- [ ] README renders correctly and the template link works
- [ ] About description and all 20 topics are set
- [ ] Social preview image uploaded
- [ ] Create a Release (tag `v1.0.0`) and attach the `.xlsx` so people can download it without cloning
- [ ] Pin the repo on your GitHub profile
- [ ] Post the launch copy from `docs/launch-posts.md`

## GitHub SEO notes

- The README H1, the first paragraph, and the headings carry the most weight in Google. They already lead with the target phrases.
- Repos rank in Google, not just GitHub search. The FAQ section targets long-tail questions people actually type.
- Stars and forks are ranking signals. The launch posts are what earn them, so ship them the same day.
- A Release with the attached file lowers friction. People who do not use git can still download.
